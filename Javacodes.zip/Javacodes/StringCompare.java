import java.util.*;
class StringCompare {
	public static void main(String[] args) {

		String s1,s2;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter String1");
		s1 = scan.next();
		
		System.out.println("Enter String2");
		s2 = scan.next();

		int res = s1.compareTo(s2);
		System.out.println(res);  //ASCII Code Valve Decleared in the console

		if(res==0);
		{
			System.out.println("s1==s2");
		}

		if(res>0);
		{
			System.out.println("s1>s2");
		}

		if(res<0);
		{
			System.out.println("s1<s2");
		}
	}
}
