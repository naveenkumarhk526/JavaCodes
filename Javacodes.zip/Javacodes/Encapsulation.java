public class Encapsulation {
    private String name;
    private int age;

    // Constructor
    public Encapsulation(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Setter for age
    public void setAge(int age) {
        this.age = age;
    }

    public static void main(String[] args) {
        // Creating a Person object
        Encapsulation encp = new Encapsulation("Naveen", 23);

        // Accessing name and age using getters
        System.out.println("Name: " + encp.getName());
        System.out.println("Age: " + encp.getAge());

        // Using setters to modify name and age
        encp.setName("NaveenKumar");
        encp.setAge(22);

        // Accessing modified name and age using getters
        System.out.println("Modified Name: " + encp.getName());
        System.out.println("Modified Age: " + encp.getAge());
    }
}

/*Why Encapsulation?
In Java, encapsulation helps us to keep related fields and methods together, which makes our code cleaner and easy to read.
It helps to control the values of our data fields.*/