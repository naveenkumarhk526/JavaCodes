import java.util.Scanner;

public class OneDimensionalArray {
    public static void main(String[] args) {

		int i;
        int a [] = new int [5];
		Scanner scan = new Scanner(System.in);
        
		for (i = 0; i <=a.length-1; i++) {
         System.out.println("Elements of the 1D array:");
		 a[i]=scan.nextInt();
		}
        for (i = 0; i <=a.length-1; i++) {
        
            System.out.print(a[i] + " ");
        }
    }
}
