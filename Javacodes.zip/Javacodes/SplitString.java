// write a java program to split a giver string at a specified character
/*import java.util.*;
class StringTokenizerDemo {
	public static void main(String[] args) {

		String s1 = "Raja Ram Mohan Roy";
		StringTokenizer str = new StringTokenizer(s1, " ");
		while (str.hasMoreTokens()==true);
		{
			String token = str.nextToken();
			System.out.println(token);
		}
		
	}
}
*/
import java.util.Scanner;

public class SplitString {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        
        System.out.print("Enter the character to split at: ");
        char splitChar = scanner.next().charAt(0);
        
        String[] parts = splitString(input, splitChar);
        
        System.out.println("Split parts:");
        for (String part : parts) {
            System.out.println(part);
        }
    }
    
    public static String[] splitString(String str, char splitChar) {
        return str.split(String.valueOf(splitChar));
    }
}
