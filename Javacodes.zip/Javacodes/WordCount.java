//write a java program to count the number of words in a given statement

import java.util.*;
public class WordCount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a statement: ");
        String statement = scanner.nextLine();
        
        int wordCount = countWords(statement);
        
        System.out.println("Number of words: " + wordCount);
    }
    
    public static int countWords(String str) {
        if (str == null || str.isEmpty()) {
            return 0;
        }

        // Split the string by whitespace characters
        String[] words = str.split("\\s+");
        
        // Count the number of words
        return words.length;
    }
}


