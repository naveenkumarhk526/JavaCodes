import java.util.Scanner;

class AddTwoIntegers 
{
	public static void main(String[] args) 
	{
		int a,b,c;
		Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter the valve of a: ");
        a = scan.nextInt();
        
        System.out.print("Enter the valve of b: ");
        b = scan.nextInt();
        
        c = a + b;
        
        System.out.println(c);
    }

}

