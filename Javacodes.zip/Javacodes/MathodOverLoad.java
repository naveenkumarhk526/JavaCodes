//write a simple java program using a method over loading 
public class MathodOverLoad { 

    // Overloaded sum(). This sum takes two int parameters 
    public int sum(int x, int y) { return (x + y); } 
  
    // Overloaded sum(). This sum takes three int parameters 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
  
    // Overloaded sum(). This sum takes two double parameters 
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
  
    public static void main(String args[]) 
    { 
        Sum s = new Sum(); 
        System.out.println(s.sum(10, 20)); 
        System.out.println(s.sum(10, 20, 30)); 
        System.out.println(s.sum(10.5, 20.5));		  Output:
															30
															60
															31.0
    } 
}

Different Ways of Method Overloading in Java
   * Changing the Number of Parameters.
   * Changing Data Types of the Arguments.
   * Changing the Order of the Parameters of Methods.

1. Changing the Number of Parameters
import java.io.*; 
  
// Class 1 
// Helper class 
class Product { 
    // Method 1 
    // Multiplying two integer values 
    public int multiply(int a, int b) 
    { 
        int prod = a * b; 
        return prod; 
    } 
  
    // Method 2 
    // Multiplying three integer values 
    public int multiply(int a, int b, int c) 
    { 
        int prod = a * b * c; 
        return prod; 
    } 
} 
  
// Class 2 
// Main class 
class GFG { 
    // Main driver method 
    public static void main(String[] args) 
    { 
        // Creating object of above class inside main() 
        // method 
        Product ob = new Product(); 
  
        // Calling method to Multiply 2 numbers 
        int prod1 = ob.multiply(1, 2); 
  
        // Printing Product of 2 numbers 
        System.out.println( "Product of the two integer value :" + prod1); 
  
        // Calling method to multiply 3 numbers 
        int prod2 = ob.multiply(1, 2, 3); 
  
        // Printing product of 3 numbers 
        System.out.println(  "Product of the three integer value :" + prod2);      Output:
                                                                                          Product of the two integer value :2
                                                                                          Product of the three integer value :6
    } 
}

2. Changing Data Types of the Arguments:

import java.io.*; 
  
// Class 1 
// Helper class 
class Product { 
    // Multiplying three integer values 
    public int Prod(int a, int b, int c) 
    { 
        int prod1 = a * b * c; 
        return prod1; 
    } 
  
    // Multiplying three double values. 
    public double Prod(double a, double b, double c) 
    { 
        double prod2 = a * b * c; 
        return prod2; 
    } 
} 
  
class GFG { 
    public static void main(String[] args) 
    { 
        Product obj = new Product(); 
  
        int prod1 = obj.Prod(1, 2, 3); 
        System.out.println("Product of the three integer value :" + prod1); 
  
        double prod2 = obj.Prod(1.0, 2.0, 3.0); 
        System.out.println("Product of the three double value :" + prod2);               Output:
																				             Product of the three integer value :6
																				             Product of the three double value :6.0
    } 
}


3. Changing the Order of the Parameters of Methods:

// Java Program to Illustrate Method Overloading 
// By changing the Order of the Parameters 

// Importing required classes 
import java.io.*; 

// Class 1 
// Helper class 
class Student { 
	// Method 1 
	public void StudentId(String name, int roll_no) 
	{ 
		System.out.println("Name :" + name + " " + "Roll-No :" + roll_no); 
	} 

	// Method 2 
	public void StudentId(int roll_no, String name) 
	{ 
		// Again printing name and id of person 
		System.out.println("Roll-No :" + roll_no + " " + "Name :" + name); 
	} 
} 

// Class 2 
// Main class 
class GFG { 
	// Main function 
	public static void main(String[] args) 
	{ 
		// Creating object of above class 
		Student obj = new Student(); 

		// Passing name and id 
		// Note: Reversing order 
		obj.StudentId("Naveen", 1); 
		obj.StudentId(2, "Kumar");            Output:
													Name :Naveen  Roll-No :1
													Roll-No :2    Name :Kumar  
	} 
}


Can we overload main() in Java?
// Java program with overloaded main() 
import java.io.*; 

public class Test { 
	// Normal main() 
	public static void main(String[] args) 
	{ 
		System.out.println("Hi Geek (from main)"); 
		Test.main("Geek"); 
	} 

	// Overloaded main methods 
	public static void main(String arg1) 
	{ 
		System.out.println("Hi, " + arg1); 
		Test.main("Dear Geek", "My Geek"); 
	} 

	public static void main(String arg1, String arg2) 
	{ 
		System.out.println("Hi, " + arg1 + ", " + arg2);     Output:
															        Hi Geek (from main)
																	Hi, Geek
																	Hi, Dear Geek, My Geek
	} 
}
