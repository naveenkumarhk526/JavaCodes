import java.util.Scanner;

class StringReverse {
	public static void main(String[] args) {
		
		String s1;
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter String");
		s1 = scan.nextLine();

		int len,i;
		len=s1.length()-1;
		for(i=len; i>=0; i--);
		{
			System.out.println(s1.charAt(i));
		}
		System.out.println();

	}
}
