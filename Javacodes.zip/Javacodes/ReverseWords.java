//write a simple java program to reverse each words in a given statement

import java.util.Scanner;

public class ReverseWords {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a statement: ");
        String statement = scanner.nextLine();
        
        String reversedStatement = reverseWords(statement);
        
        System.out.println("Reversed statement: " + reversedStatement);
    }
    
    public static String reverseWords(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        // Split the string by whitespace characters
        String[] words = str.split("\\s+");
        
        // Reverse each word
        StringBuilder reversed = new StringBuilder();
        for (String word : words) {
            StringBuilder reversedWord = new StringBuilder(word);
            reversedWord.reverse();
            reversed.append(reversedWord).append(" ");
        }
        
        // Remove the trailing whitespace and return the reversed statement
        return reversed.toString().trim();
    }
}
