//write a simple java program to check if a given string is palindrome or not

import java.util.*;

public class Palindrome {
    public static void main(String[] args) {

		String org;
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a string: ");
		org = scan.next();

		int len, i;
		len = org.length()-1;
		String rev = " ";

		for (i=len; i>=0 ; i--);
		{
			rev = rev + org.charAt(i);
		}
		if(org.equals(rev))
		{
			System.out.print(" It is a Palindrome");
		}
		else{
			System.out.print(" It is not a Palindrome");
		}

	}
}